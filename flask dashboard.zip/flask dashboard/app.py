from flask import Flask, render_template, request, jsonify
import pandas as pd

app = Flask(__name__)

# Main route for dashboard
@app.route('/')
def index():
    return render_template('dashboard.html')

# Route for uploading and processing Excel data
@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({"error": "No file uploaded"}), 400
    file = request.files['file']
    if file.filename == '':
        return jsonify({"error": "No selected file"}), 400
    if file and file.filename.endswith('.xlsx'):
        data = pd.read_excel(file)

        # Ensure required columns are in the data
        required_columns = {'OrderDate', 'Region', 'Manager', 'SalesMan', 'Item', 'Units', 'Unit_price', 'Sale_amt'}
        if not required_columns.issubset(data.columns):
            return jsonify({"error": "File is missing one or more required columns"}), 400

        # Convert OrderDate to datetime format with error handling
        try:
            data['OrderDate'] = pd.to_datetime(data['OrderDate'], errors='coerce')
        except Exception as e:
            return jsonify({"error": f"Error converting OrderDate to datetime: {e}"}), 400

        # Drop rows with invalid dates in OrderDate
        data = data.dropna(subset=['OrderDate'])

        # Aggregate data for dashboard metrics
        total_sales = data['Sale_amt'].sum()
        total_units_sold = data['Units'].sum()
        avg_unit_price = data['Unit_price'].mean()

        # Sales over time (monthly)
        sales_over_time = data.groupby(data['OrderDate'].dt.to_period('M')).agg({'Sale_amt': 'sum'}).reset_index()
        sales_over_time['OrderDate'] = sales_over_time['OrderDate'].dt.to_timestamp()

        # Sales by region
        sales_by_region = data.groupby('Region').agg({'Sale_amt': 'sum'}).reset_index()

        # Sales by item (top 5 items)
        sales_by_item = data.groupby('Item').agg({'Sale_amt': 'sum'}).nlargest(5, 'Sale_amt').reset_index()

        # Sales by salesperson
        sales_by_salesperson = data.groupby('SalesMan').agg({'Sale_amt': 'sum'}).reset_index()

        # Average sale amount by region
        avg_sales_by_region = data.groupby('Region').agg({'Sale_amt': 'mean'}).reset_index()

        # Prepare JSON data for the frontend
        summary_data = {
            "total_sales": total_sales,
            "total_units_sold": total_units_sold,
            "avg_unit_price": avg_unit_price,
        }
        charts_data = {
            "sales_over_time": {
                "x": sales_over_time['OrderDate'].astype(str).tolist(),
                "y": sales_over_time['Sale_amt'].tolist()
            },
            "sales_by_region": {
                "x": sales_by_region['Region'].tolist(),
                "y": sales_by_region['Sale_amt'].tolist()
            },
            "sales_by_item": {
                "x": sales_by_item['Item'].tolist(),
                "y": sales_by_item['Sale_amt'].tolist()
            },
            "sales_by_salesperson": {
                "x": sales_by_salesperson['SalesMan'].tolist(),
                "y": sales_by_salesperson['Sale_amt'].tolist()
            },
            "avg_sales_by_region": {
                "x": avg_sales_by_region['Region'].tolist(),
                "y": avg_sales_by_region['Sale_amt'].tolist()
            }
        }

        return jsonify({"summary": summary_data, "charts": charts_data})
    return jsonify({"error": "Invalid file format. Please upload an Excel file."}), 400

if __name__ == '__main__':
    app.run(debug=True)
