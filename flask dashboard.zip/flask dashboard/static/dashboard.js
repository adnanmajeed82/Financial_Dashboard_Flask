document.getElementById('fileInput').addEventListener('change', function(event) {
    const file = event.target.files[0];
    if (file) {
        const formData = new FormData();
        formData.append('file', file);

        fetch('/upload', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                alert(data.error);
            } else {
                // Display summary metrics
                document.getElementById('totalSales').textContent = data.summary.total_sales.toFixed(2);
                document.getElementById('totalUnitsSold').textContent = data.summary.total_units_sold;
                document.getElementById('avgUnitPrice').textContent = data.summary.avg_unit_price.toFixed(2);

                // Render charts
                Plotly.newPlot('salesOverTime', [{
                    x: data.charts.sales_over_time.x,
                    y: data.charts.sales_over_time.y,
                    type: 'scatter',
                    mode: 'lines+markers',
                    name: 'Sales Over Time'
                }], { title: 'Sales Over Time' });

                Plotly.newPlot('salesByRegion', [{
                    x: data.charts.sales_by_region.x,
                    y: data.charts.sales_by_region.y,
                    type: 'bar',
                    name: 'Sales by Region'
                }], { title: 'Sales by Region' });

                Plotly.newPlot('salesByItem', [{
                    x: data.charts.sales_by_item.x,
                    y: data.charts.sales_by_item.y,
                    type: 'bar',
                    name: 'Top 5 Items by Sales Amount'
                }], { title: 'Top 5 Items by Sales Amount' });

                Plotly.newPlot('salesBySalesperson', [{
                    x: data.charts.sales_by_salesperson.x,
                    y: data.charts.sales_by_salesperson.y,
                    type: 'bar',
                    name: 'Sales by Salesperson'
                }], { title: 'Sales by Salesperson' });

                Plotly.newPlot('avgSalesByRegion', [{
                    x: data.charts.avg_sales_by_region.x,
                    y: data.charts.avg_sales_by_region.y,
                    type: 'bar',
                    name: 'Average Sale Amount by Region'
                }], { title: 'Average Sale Amount by Region' });
            }
        })
        .catch(error => console.error('Error:', error));
    }
});
